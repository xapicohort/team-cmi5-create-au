This is not my course, it's a tutorial based off of Devlin Peck's xapi tutorial.
I am testing to see whether the CATAPULT system accepts and reads all of the xAPI statements in this course, in order to craft my test course for the cohort demo.

Liz