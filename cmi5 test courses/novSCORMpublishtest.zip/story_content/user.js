function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6mcWEv1DBdV":
        Script1();
        break;
      case "5g5WVebtWzg":
        Script2();
        break;
      case "6P36X845L6s":
        Script3();
        break;
      case "6m9CcJ6lCGP":
        Script4();
        break;
      case "6YrdiNFuhup":
        Script5();
        break;
      case "6RGWGt4Vfsu":
        Script6();
        break;
      case "5ZeLxDEpe0W":
        Script7();
        break;
      case "6FokElPEYIy":
        Script8();
        break;
      case "6L3JiUS7Wan":
        Script9();
        break;
      case "6VuZ2htCtC8":
        Script10();
        break;
      case "6atEZDBQgmX":
        Script11();
        break;
      case "6RB7WMKPylp":
        Script12();
        break;
      case "5z5pETpDAiG":
        Script13();
        break;
      case "6BsWh6loXtF":
        Script14();
        break;
  }
}

function Script1()
{
  manageTimer.course.start()
manageTimer.slide.start()
}

function Script2()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", false)
}

function Script3()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", false)
}

function Script4()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", true)
}

function Script5()
{
  sendViewed("Cheatsheet", "http://example.com/cheatsheet")
}

function Script6()
{
  manageTimer.slide.reset()
}

function Script7()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", true)
}

function Script8()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", false)
}

function Script9()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", false)
}

function Script10()
{
  sendViewed("Cheatsheet", "http://example.com/cheatsheet")
}

function Script11()
{
  sendFailed("Quiz 1", "http://example.com/quiz-1")
}

function Script12()
{
  sendPassed("Quiz 1", "http://example.com/quiz-1")
}

function Script13()
{
  populateLeaderboard()
}

function Script14()
{
  sendStatement("answered", "http://adlnet.gov/expapi/verbs/answered", "Survey Question", "http://example.com/survey-question", "Survey question in Liz's sample quiz", "http://adlnet.gov/expapi/activities/question", "userResponseOne")
}

