function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5qW3f311lc4":
        Script1();
        break;
      case "5WptxioKFWU":
        Script2();
        break;
      case "6HSAp7MMbxG":
        Script3();
        break;
      case "5XnCgEkjyfJ":
        Script4();
        break;
      case "65S36ImmuZY":
        Script5();
        break;
      case "6hJcL1oCVo6":
        Script6();
        break;
      case "6QnTR9IJKBj":
        Script7();
        break;
      case "6GdCStk05fb":
        Script8();
        break;
      case "6gOP3xgPDZ3":
        Script9();
        break;
      case "5ggmWq1Hm3c":
        Script10();
        break;
      case "6NCMfBlj8CD":
        Script11();
        break;
      case "6hibJp2a2bj":
        Script12();
        break;
      case "6Tc5AzizN39":
        Script13();
        break;
      case "6eWrbt0yiwl":
        Script14();
        break;
      case "6MilAxFZE4D":
        Script15();
        break;
  }
}

function Script1()
{
  sendLaunched("launched", "http://example.com/launched-course");
}

function Script2()
{
  manageTimer.course.start()
manageTimer.slide.start()
}

function Script3()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", false)
}

function Script4()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", true)
}

function Script5()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", false)
}

function Script6()
{
  sendViewed("Cheatsheet", "http://example.com/cheatsheet")
}

function Script7()
{
  manageTimer.slide.reset()
}

function Script8()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", false)
}

function Script9()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", true)
}

function Script10()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", false)
}

function Script11()
{
  sendViewed("Cheatsheet", "http://example.com/cheatsheet")
}

function Script12()
{
  sendFailed("Quiz 1", "http://example.com/quiz-1")
}

function Script13()
{
  sendPassed("Quiz 1", "http://example.com/quiz-1")
}

function Script14()
{
  sendResponded("responded", "http://adlnet.gov/expapi/verbs/responded", "Planet question in Liz's sample quiz", "http://adlnet.gov/expapi/activities/question", "userResponseOne");
}

function Script15()
{
  sendSatisfied("satisfied", "http://example.com/exit-course");

sendCompleted("completed", "http://example.com/exit-course");
}

