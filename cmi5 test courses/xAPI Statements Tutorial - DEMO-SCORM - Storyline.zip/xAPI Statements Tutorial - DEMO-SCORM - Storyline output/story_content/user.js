function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5tYl3MDGbSa":
        Script1();
        break;
      case "5xwuypLBucY":
        Script2();
        break;
      case "5dDEaERz5mO":
        Script3();
        break;
      case "6S161DMyiEL":
        Script4();
        break;
      case "6bb5xByzjAW":
        Script5();
        break;
      case "6pcUPS2mTK3":
        Script6();
        break;
      case "69XBqONstnh":
        Script7();
        break;
      case "6rVYaprlu59":
        Script8();
        break;
      case "6QgcGBKSTKb":
        Script9();
        break;
      case "6Bm5GoxkYta":
        Script10();
        break;
      case "5fiyRfjfYXA":
        Script11();
        break;
      case "6VDLTYGE6sJ":
        Script12();
        break;
      case "6cfJkzGww62":
        Script13();
        break;
      case "6igGBaAtKLO":
        Script14();
        break;
      case "6IyzIGZKjLG":
        Script15();
        break;
  }
}

function Script1()
{
  sendLaunched("launched", "http://example.com/launched-course");
}

function Script2()
{
  manageTimer.course.start()
manageTimer.slide.start()
}

function Script3()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", false)
}

function Script4()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", true)
}

function Script5()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", false)
}

function Script6()
{
  sendViewed("Cheatsheet", "http://example.com/cheatsheet")
}

function Script7()
{
  manageTimer.slide.reset()
}

function Script8()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", false)
}

function Script9()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", true)
}

function Script10()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", false)
}

function Script11()
{
  sendViewed("Cheatsheet", "http://example.com/cheatsheet")
}

function Script12()
{
  sendFailed("Quiz 1", "http://example.com/quiz-1")
}

function Script13()
{
  sendPassed("Quiz 1", "http://example.com/quiz-1")
}

function Script14()
{
  sendResponded("responded", "http://adlnet.gov/expapi/verbs/responded", "Planet question in Liz's sample quiz", "http://adlnet.gov/expapi/activities/question", "userResponseOne");
}

function Script15()
{
  sendSatisfied("satisfied", "http://example.com/exit-course");

sendCompleted("completed", "http://example.com/exit-course");
}

