function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5Y6zLeRzaK9":
        Script1();
        break;
      case "65fVRW3TDzE":
        Script2();
        break;
      case "60znQsYZ2HC":
        Script3();
        break;
      case "5W17xl5nuJO":
        Script4();
        break;
      case "605A2RqbRuR":
        Script5();
        break;
      case "5tNsrGCri9g":
        Script6();
        break;
      case "6DrKx0EsJGW":
        Script7();
        break;
      case "5qPG5ujTeg9":
        Script8();
        break;
      case "5WIfVDQSWsw":
        Script9();
        break;
      case "5oKqaCKsVOu":
        Script10();
        break;
      case "5eHLttBhtxE":
        Script11();
        break;
      case "6lg4VsDTIVa":
        Script12();
        break;
      case "6HaOMQOc9U5":
        Script13();
        break;
      case "6HeoxzYxYGv":
        Script14();
        break;
  }
}

function Script1()
{
  manageTimer.course.start()
manageTimer.slide.start()
}

function Script2()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", false)
}

function Script3()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", false)
}

function Script4()
{
  sendAnswered("Question 1", "http://example.com/question-1", "questionOneResponse", true)
}

function Script5()
{
  sendViewed("Cheatsheet", "http://example.com/cheatsheet")
}

function Script6()
{
  manageTimer.slide.reset()
}

function Script7()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", true)
}

function Script8()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", false)
}

function Script9()
{
  sendAnswered("Question 2", "http://example.com/question-2", "questionTwoResponse", false)
}

function Script10()
{
  sendViewed("Cheatsheet", "http://example.com/cheatsheet")
}

function Script11()
{
  sendFailed("Quiz 1", "http://example.com/quiz-1")
}

function Script12()
{
  sendPassed("Quiz 1", "http://example.com/quiz-1")
}

function Script13()
{
  populateLeaderboard()
}

function Script14()
{
  sendStatement("answered", "http://adlnet.gov/expapi/verbs/answered", "Survey Question", "http://example.com/survey-question", "Survey question in Liz's sample quiz", "http://adlnet.gov/expapi/activities/question", "userResponseOne")
}

